import funcoes

usuarios = {
    
}

while True:
    dados = input("Entre com os dados neste formato: login,nome,data de último acesso,máquina (Use Sair para encerrar o programa): ")
    if dados == "Sair":
        break
    login, nome, data, maquina = dados.split(", ")
    if login not in usuarios:
        usuarios[login] = {"nome": nome, "data de último acesso": data, "Máquina": maquina}


while True:
    opcao = int(input("Digite uma opção: \n1: Listar o nome de todos os usuários\n2: Listar dados de um usuário\n3: Listar os nomes dos usuários com último acesso em uma data específica\n4: Alterar dados de um usuário\n5: Excluir um usuário\n6: Digite 6 para sair: "))
    if opcao == 6:
        break
    if opcao == 1:
        for usuario in usuarios.values():
            print(f"Nome: {usuario['nome']}")
    if opcao == 2:
        for key in pessoas:
            print(f"Nome: {pessoas[key]['nome']}")