def listarUsuarios():
    for usuario in usuarios.values():
            print(f"Nome: {usuario['nome']}")
    




def listarDados():
    for usuario in usuarios.values():
            print(f"Login: {usuario['login']}, Nome: {usuario['nome']}, Último acesso: {usuario['data']}, Máquina: {usuario['maquina']}")
    return usuario





# def excluirUsuario():
