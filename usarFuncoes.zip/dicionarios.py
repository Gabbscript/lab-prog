pessoas = {}

while True:
    dados = input("Entre com os dados no seguinte formato: CPF,Fulano,40 (0 - para sair): ")
    if dados == "0":
        break
    cpf, nome, idade = dados.split(",")
    if cpf not in pessoas:
        pessoas[cpf] = {"nome": nome, "idade": idade}
    else:
        print("CPF já cadastrado!")


# pessoas["1"] = {"nome": "Beltrano", "idade": 45}
# pessoas.update({"2": {"nome": "Beltrano", "idade": 45}})
# chaveParaPesquisar = input("Entre com o código a ser pesquisado: ")
# pessoa = pessoas.get(chaveParaPesquisar)
# if pessoa == None:
#     print("O código pesquisado não existe!")
# else:
#     print("O código pesquisado pertence a: ", pessoa["nome"])


# Percorrer por chave
# for key in pessoas:
#     print(f"Nome: {pessoas[key]['nome']}, idade: {pessoas[key]['idade']}")

# Percorrer por valor
# for pessoa in pessoas.values():
#     print(f"Nome: {pessoa['nome']}, idade: {pessoa['idade']}")

# Percorrer por chave e valor
for cpf, pessoa in pessoas.items():
    print(f"CPF - {cpf} - Nome: {pessoa['nome']}, idade: {pessoa['idade']}")