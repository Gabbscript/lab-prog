# pessoasLista = [
#     ["Fulano", 22]
#     ["Ciclano", 33]
# ]

pessoas = {
    1: {"nome": "Fulano", "idade": 22},
    2: {"nome": "Ciclano", "idade": 33},
    3: {"nome": "Fulano", "idade": 44}
}

# pessoas.update({"2": {"nome": "Beltrano", "Idade": 45}})

chaveParaPesquisar = input("Entre com o código a ser pesquisado: ")
pessoa = pessoas.get(chaveParaPesquisar)
if pessoa == None:
    print("O código pesquisado não existe")
else:
    print("O código pesquisado pertence a: ", pessoa['nome'])

#Percorrer por chave
# for key in pessoas:
#     print(f"Nome: {pessoas[key]['nome']}, idade: {pessoas[key]['idade']}")

#Percorrer por valor
# for pessoa in pessoas.values():
#     print(f"Nomes: {pessoa['nome']}, idade: {pessoa['idade']}")


#Percorrer por chave e valor
# for chave, pessoa in pessoas.items():
#     print(f"Chave - {chave} - Nome: {pessoa['nome']}, Idade: {pessoa['idade']}")